var crJsNs = crJsNs || {};

crJsNs.search = {
  //検索を実行するfunction
  searchResult: function() {

	//URLパラメータから検索文字部分を取得
	var url = location.href;
    var key = String('KEY').replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + key + "(=([^&#]*)|&|#|$)"),
		results = regex.exec(url);
	var searchStr = results[2].replace(/\+/g, " ");

	//URLパラメータから検索タイプ部分を取得
    var searchTypeKey = String('TYPE').replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + searchTypeKey + "(=([^&#]*)|&|#|$)"),
		results2 = regex.exec(url);
	var searchType = results2[2].replace(/\+/g, " ");


	//console.log('function実行時のsearchStr=' + searchStr);
	var decodeSearchStr = decodeURIComponent(searchStr);
	//console.log('decodeしたsearchStr=' + decodeSearchStr);
    var result = new String;
    var any_result = new Boolean (false);
	//search_moji = z2h_ascii(searchStr);

    //search_moji = searchStr;
	search_moji = decodeSearchStr;


    sanitizer_RE = new RegExp("(\\.|\\?|\\*|\\+|\\^|\\$|\\{|\\}|\\(|\\)|\\[|\\]|\\\\)","g");
    search_moji = search_moji.replace(sanitizer_RE, "\\$1");
    search_RE = new RegExp(search_moji, "gi");    
    result = '<div class="search-result-box">';
    result = result + '<h3 class="search-result-title">' + resultTitle + '</h3>';
    var resultCount = 0;
    var linkRef;
    var linkHash;
    var linkUrl;
    var linkTitle;
    var linkDesc;
    var resultTopic;
    var k = 0;
    var resultArray = new Array();;
    var multiplenumber = 10;
    var resultTempStr = "";

    
	//searchStr = crJsNs.search.encodeStr(searchStr);
	searchStr = crJsNs.search.encodeStr(decodeSearchStr);

//    resultTopic = '<dl class="search-result-items">';

	//Search The text as wellにチェックがあった場合は本文（contents)で検索
	//チェックがない時はtitleで検索
	if(searchType == '1'){
		console.log('チェックあり');
		searchTarget = contents;
	}
	else {
		console.log('チェックなし');
		searchTarget = title;
	}

    for (s in searchTarget) {
	  
	  console.log(contents[s]);
	  console.log('検索実行時のsearchStr=' + searchStr);

      ici = searchTarget[s].search(search_RE);
      if (ici >= 0) {
        
        any_result = true;
        resultCount = resultCount + searchTarget[s].match(search_RE).length;
        linkHash = urlHash[s];
        linkHash = crJsNs.search.encodeStr(linkHash);
		linkTitle = title[s];
		linkDesc = contents[s];
		//contentsの中で最初に該当した箇所の前30文字を取る
		//contentsの中で最初に該当した箇所の後ろ30文字を取る
		var wordinContents = search_RE.exec(linkDesc);
		if (wordinContents) {
			var startPosition = wordinContents['index'];
			//contentsの中で初出の検索語句開始位置（startPosition）から100文字前までを取る
			//startPositionが30以上だった時のみで、それ以外は前すべてを取る
			if (startPosition >= 31) {
				linkDesc = linkDesc.substring(startPosition - 200, startPosition);
			}
			else {
				linkDesc = linkDesc.substring(0, startPosition);
			}
			//contentsの中で初出の検索語句開始位置（startPosition）に検索語句の文字数 + 100文字後ろまでを取る
			linkDesc = '...' + linkDesc + contents[s].substring(startPosition, startPosition + decodeSearchStr.length + 200) + '...';
		}

		resultTopic ="";

        resultTopic = resultTopic + '<dt class="search-result-item">';
		resultTopic = resultTopic + '<span class="search-result-item-title" data-result-file="' + linkHash + '"' + 'data-search-word="' + searchStr + '">';
			
		//<span class="search-result-item-title" date-result-file="topic_1" data-search-word="safety">

        resultTopic = resultTopic + linkTitle;
        resultTopic = resultTopic + '</span>';
        resultTopic = resultTopic + '</dt>';
        
        k++;

		//titleだけに絞った検索であれば内容を表示しない
		if(searchType == '1') {
        	resultTopic = resultTopic + '<dd class="search-result-contents"><p>';
        	resultTopic = resultTopic + linkDesc;
        	resultTopic = resultTopic + '</p></dd>';
		}

		resultArray.push(resultTopic);

      }
    }
    
    if (any_result == false) {
        resultTempStr = "<div class=\"search-result-notfound\">Not found. Please try another keyword.</div>";
	}
	else
	{
	
		for ( var i = 0; i < resultArray.length; i++ ) 
		{

			if( (i % multiplenumber) == 0 )
			{
				resultTempStr += '<div class="selection" id="page-' + (i / multiplenumber + 1) + '">';
				resultTempStr += '<dl class="search-result-items">'
			}

			resultTempStr += resultArray[i];

			if( ((i + 1) % multiplenumber) == 0 )
			{
				resultTempStr += '</div>'
				resultTempStr += '</dl>'

			}
			else if(resultArray.length == i+1)
			{
				resultTempStr += '</div>'
				resultTempStr += '</dl>'

			}

		}

		if(multiplenumber < resultArray.length)
		{
		   resultTempStr += '<div class="pagination-holder clearfix"><div id="light-pagination" class="pagination"></div></div>';
		}	
	
	}
	
    //resultTopic = resultTopic + '</dl>';
    result = result + '<p class="search-result-about">' + resultPrefix + ' ' + k + ' ' + resultSuffix + '</p>';
    result = result + '</div>';
/*
    result = result + '<div class="search-result-note"><dl><dt></dt><dd>';
    result = result + resultNote;
    result = result + '</dd></dl></div>';
*/
    result = result + '<div>';
//    result = result + resultTopic;
    result = result + resultTempStr;
    result = result + '</div>';
    
    return result;
  },
  
  encodeStr: function(prmStr) {
    var strValue;
    strValue = encodeURIComponent(prmStr);
    strValue = strValue.replace(/\(/g, "%28");
    strValue = strValue.replace(/\)/g, "%29");
    strValue = strValue.replace(/'/g,  "%27");
    return strValue;
  },

  z2h_ascii:function(src) {
    var str = new String;
    var len = src.length;
    for (var i = 0; i < len; i++) {
      var c = src.charCodeAt(i);
      if (c >= 65281 && c <= 65374 && c != 65340) {
        str += String.fromCharCode(c - 65248);
      } else if (c == 8217) {
        str += String.fromCharCode(39);
      } else if (c == 8221) {
        str += String.fromCharCode(34);
      } else if (c == 12288) {
        str += String.fromCharCode(32);
      } else if (c == 65507) {
        str += String.fromCharCode(126);
      } else if (c == 65509) {
        str += String.fromCharCode(92);
      } else {
        str += src.charAt(i);
      } 
    }
    return str;
  },

  highlight: function(text, words, tag) {
    // タグが与えられてなければデフォルトのタグを設定する
  	tag = tag || 'span';
    var i, len = words.length, re;
    for (i = 0; i < len; i++) {
   	    // マッチした全てを強調するための正規表現
       	re = new RegExp(words[i], 'g');
        if (re.test(text)) {
   	        text = text.replace(re, '<' + tag + ' class="highlight">$&</' + tag + '>');

			console.log(text);

        }
    }
   	return text;
  },

  highlightHTML: function(html, word, cls){

	//console.log(word);

    if (!cls) { cls = 'highlight'; }
    $.each(word, function(i,w){
        html = html.replace(new RegExp('('+w+')|(<[0-9a-zA-Z]+(?:[ \t\n\f\r]+[^ \x00-\x1F\x7F"\'>/=]+(?:[ \t\n\f\r]*=[ \t\n\f\r]*(?:[^ \t\n\f\r"\'=><`]+|\'[^\x00-\x08\x0B\x0E-\x1F\x7F\']*\'|"[^\x00-\x08\x0B\x0E-\x1F\x7F"]*"))?)*[ \t\n\f\r]*/?>)|(<\/[0-9a-zA-Z]+[ \t\n\f\r]*>)', 'gi'), function(){
            for (var j=1,jMax=arguments.length-2; j<jMax; j++) {
                if (arguments[j]) {
                    if (j == 1) {
                        return '<span class="'+cls+'">'+ arguments[j] +'</span>';
                    } else {
                        return arguments[j];
                    }
                }
            }
        });
    });
    return html;
  }

};
$(function(){
	$(document).on('click', '.search-result-item-title', function(){
		var page = $(this).attr('data-result-file');
		var word = $(this).attr('data-search-word');
//		location.hash = page + '?SEARCH=' + word;
		window.location.href  = page + '?SEARCH=' + word;

    });

});



$(function(){

  //検索フォーム内でEnterを押下した時のイベント
	$(".search-input").keydown(function (event) {
		if (event.keyCode == 13) {
      var searchStr = $(".search-input").val();
      //検索語句入力がなければ何もしない
      if (searchStr != '') {
        //検索語句をエンコード
        searchStr = encodeURIComponent(searchStr);
        
		var searchType;

		if($('[name="title-only"]').prop('checked'))
		{
			searchType = 0;
		}
		else
		{
			searchType = 1;
		}

        //location.hash = 'search_result?KEY=' + searchStr;
        location.hash = 'search_result?KEY=' + searchStr + '&TYPE=' + searchType;
      }
    }
  });

	$(document).on('click', '.search-run', function(){
    var searchStr = $(".search-input").val();
    //検索語句入力がなければ何もしない
    if (searchStr != '') {
      //検索語句をエンコード
      searchStr = encodeURIComponent(searchStr);
      
		var searchType;

		if($('[name="title-only"]').prop('checked'))
		{
			searchType = 0;
		}
		else
		{
			searchType = 1;
		}

      //location.hash = 'search_result?KEY=' + searchStr;
      location.hash = 'search_result?KEY=' + searchStr + '&TYPE=' + searchType;
    }
	});



});