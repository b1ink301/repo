$(function(){




var regex = /_/gm
var currentFileName = window.location.href.split('/').pop();
currentFileName = currentFileName.split("?");
currentFileName = currentFileName[0];
                
var regResult = currentFileName.match(regex);

//var topicMatch = window.location.href;
var topicMatch;


if(!regResult)
{
    topicMatch = "chapter";
}
else if(regResult.length == 2)
{
    topicMatch = "topic";
}
else
{
    topicMatch = "section";
}


$('#menu a').removeClass('selected').removeClass('open').addClass('close');
$('#menu li').removeClass('selected').removeClass('open').addClass('close');
$('#menu ul.child-list').css('display','none');

//topicか判定
//topicだった場合はsectionの情報を取得
if(topicMatch == "topic"){
    var activeMenuItem = $('.bread-clumb').find('.bread-clumb-item').last().attr('href');
    var hashSelector = $('#menu a[href="'+ activeMenuItem +'"]');
    //var sectionMatch = activeMenuItem.match(regex);
    var sectionMatch = true;

} else {
//最上位要素（chapter要素など）だった場合
    var hashSelector;
    var sectionMatch;

    if(topicMatch == "chapter")
    {
        hashSelector = $('#menu a[data-href $= "'+ currentFileName +'"]')
    }
    else
    {
        hashSelector = $('#menu a[href $= "'+ currentFileName +'"]')
    }

}



//sectionか判定
//sectionだった場合
if(topicMatch == "section" || topicMatch == "topic"){

    if(!hashSelector.hasClass('selected')){

        hashSelector.addClass('selected');
        hashSelector.removeClass('close').addClass('open');


        var hashSelectorParent = hashSelector.parents('li').parents('li');
        var hashSelectorParentList = hashSelectorParent.find('.child-list');
        var hashSelectorParentBtn = hashSelectorParent.children('a').first();
        if(!hashSelectorParent.hasClass('open')){
            //hashSelectorParent.addClass('has-child');
            hashSelectorParent.removeClass('close').addClass('open');
            hashSelectorParentBtn.removeClass('close').addClass('open');
            hashSelectorParentList.css('display','block');
        }


    }
//最上位要素（chapter要素など）だった場合
} else {

    if(!hashSelector.hasClass('selected')){
        hashSelector.addClass('selected');

        if(!hashSelector.hasClass('open')){
            hashSelector.removeClass('close').addClass('open');
        } else {
            hashSelector.removeClass('open').addClass('close');
        }

        var hashSelectorList = hashSelector.siblings('.child-list');
        hashSelectorList.css('display','block');
    }
}













});









/*ルーティングのファイル名はデータによって決定されるため
XSLT側で動的に生成しなければならない*/
$(function(){

	$.ajaxSetup({ cache: false });
	var routing = function(){
		routie({
/*
            '': function() {
				$('.content').load('topics/top.html');
			},
*/
			'search_result?*': function() {
				//クエリパラメータから検索語句を取得
				var url = window.location.href;
				var param = url.split('?');
				var key = param[1].split('=');
				var value = key[1].split('&');
				var words = decodeURIComponent(value[0]);

				var result = crJsNs.search.searchResult();

				//console.log('検索結果');
				//console.log(result);
				//console.log('words=' + words);

				$('.content').empty();
				$('.content').append(result);

				var replaceHtml = $('.content').html();

				//var html = $(result).html();
				var word = [words.toLowerCase(), words.toUpperCase()];
				var highlighted = crJsNs.search.highlightHTML(replaceHtml, word);

				$('.content').empty();
				$('.content').append(highlighted);

				var totalPage = $(result).find("div[class = 'selection'][id ^= 'page-']").length;

				//最低限の箇所のみ検索結果を表示するように設定
				$(".selection").css('display', 'none');
				$("#page-1").css('display', 'block');

                $('#layout').removeClass('active');
                $('#close_bt_div').css('display','none');

				$(".pagination").pagination({
					items: totalPage,
					displayedPages: 1,
					cssStyle: 'light-theme',
					prevText:'&#x2190;',
					nextText:'&#x2192;',
					onPageClick: function(currentPageNumber){
						showPage(currentPageNumber);
					}
				})


			},

			'*': function(name) {
			//トップページと検索結果以外は全てここで受け入れる

				//検索結果から遷移してきた場合はクエリパラメータを除いた値を取得
				if(name.match(/\?SEARCH=/))
				{
					name = name.substring(0, name.indexOf("?"));
				}
			

                wordHighlight();

                setTimeout(function() {
					$('.swiper-button-prev').fadeOut(1000);
					$('.swiper-button-next').fadeOut(1000);
				}, 2000);

            }


		});
	};
	routing();

});

var swiper = null;

/* 左メニュー関連 */
$(function(){

	$(".has-child").on("click", function() {
		$(this).next().slideToggle();
	});

	//選択したメニューの背景色変更
	$('#menu a').on('click',function(){
		//一度全ての選択状況を解除
		$("#menu a").removeClass('selected');
		//自身を選択中に
		$(this).addClass('selected');
		/*クリックした時、openクラスがあればcloseクラスに変更
		  closeクラスだった場合はopenクラスに変更*/
		if ($(this).hasClass('open')) {
			$(this).removeClass('open');
			$(this).addClass('close');
		} else if ($(this).hasClass('close')) {
			$(this).removeClass('close');
			$(this).addClass('open');
		}
	});

	//ハンバーガーメニュー
	$('.header-left .btn_nav, .language_area .btn_nav').on('click',function(){
		if($('#layout').hasClass('active')) {
			$('#layout').removeClass('active');
            $('#close_bt_div').css('display','none');
        } else {
			$('#layout').addClass('active');

            setTimeout(function(){
                    $('#close_bt_div').css('display','block');
            },300);

		}
	});
	//本文領域をタップしたらメニューを閉じる
	$('.content, #close_bt_div, .close-button').on('click',function(){
		$('#layout').removeClass('active');
        $('#close_bt_div').css('display','none');

    });
});

/* 検索関連 */
$(function(){
	$('.search-box-open i').on('click',function(){
		$('.search-box').addClass('active');
	});
	$('.search-box-close').on('click',function(){
		$('.search-box').removeClass('active');
	});
	$('.search-run').on('click',function(){
		//モーダルが開かない?
		$('div[data-remodal-id=search-modal]').remodal();
	});

	$('.top-manual-info').on('click',function(){
		/* なぜか空のイベントハンドラがないとモーダルが開かない。
		別件ではうまくいっているのだが、要調査*/
	});
});

/* troubleshooting関連 */
$(function(){

	$('.content').on('click', '.troubleshooting-title', function() {
		$(this).nextUntil('.troubleshooting-title').slideToggle();
	});

});



//ページ送り用アイコンをフェードアウトする
$(function(){

	$('.content').on('touchstart click', function(){
		$('.swiper-button-prev').fadeIn(100, function(){
			setTimeout(function() {
				$('.swiper-button-prev').fadeOut(1000);
			}, 2000);
		});


		$('.swiper-button-next').fadeIn(100, function(){
			setTimeout(function() {
				$('.swiper-button-next').fadeOut(1000);
			}, 2000);
		
		});
	});

});



$(function(){

	$('.toppage .menu-body').on('click',  function() {
		window.location.href = $(this).attr("data-href");
	});

});



$(function(){


$(".fontChangeButtonMinus").click(function(event) {

	var fontsizeNumber = fontsizeCheck();

	if(fontsizeNumber == "")
	{
		$('.content').addClass('fontsize_1');
		$(".fontChangeButtonMinus").prop('disabled', true);
	}
	else
	{

		if(fontsizeNumber >= 1)
		{

			$('.content').removeClass('fontsize_' + fontsizeNumber);

			if(fontsizeNumber == 2)
			{
				$(".fontChangeButtonMinus").prop('disabled', true);
			}
			else if(fontsizeNumber > 2)
			{
				$(".fontChangeButtonMinus").prop('disabled', false);
			}

			fontsizeNumber = parseInt(fontsizeNumber) - parseInt(1);
			//alert(fontsizeNumber);
			$('.content').addClass('fontsize_' + fontsizeNumber);
			$(".fontChangeButtonPlus").prop('disabled', false);

}


	}

});


$(".fontChangeButtonPlus").click(function(event) {

	var fontsizeNumber = fontsizeCheck();

	if(fontsizeNumber == "")
	{
		$('.content').addClass('fontsize_3');
	}
	else
	{

		if(fontsizeNumber <= 4)
		{
			$('.content').removeClass('fontsize_' + fontsizeNumber);

			if(fontsizeNumber == 4)
			{
				$(".fontChangeButtonPlus").prop('disabled', true);
			}
			else if(fontsizeNumber < 4)
			{
				$(".fontChangeButtonPlus").prop('disabled', false);
			}


			fontsizeNumber = parseInt(fontsizeNumber) + parseInt(1);
			//alert(fontsizeNumber);

			$('.content').addClass('fontsize_' + fontsizeNumber);
			$(".fontChangeButtonMinus").prop('disabled', false);


		}


	}







	/*
	$(".content").toggleClass("big");
	$(".fontChangeButton").prop('disabled', false);
	$(this).prop('disabled', true);
	*/

});





});



function fontsizeCheck()
{
	var classTmp = $('.content').attr('class');
	var removeClassName = 'fontsize_'; // 削除するclassの一部
	reg = new RegExp("\\b" + removeClassName + "\\S+", 'g');
	var regResult = classTmp.match(reg);
	var result = "";

	//classの中にfontsize_nが含まれていたら
	if(regResult != null)
	{
		result = regResult[0].split("_")[1];
	}

	return result;
}










function wordHighlight()
{

	var url = window.location.href;
	if ( url.indexOf('?SEARCH=') != -1) {
		var param = url.split('?');
		var key = param[1].split('=');
		var value = key[1];
		var words = decodeURIComponent(value);
		//console.log($('.topic-inner').html());
		//$('.topic-inner').html(crJsNs.search.highlight($('.topic-inner').html(), words));
		var html = $('.topic-inner').html();
		var word = [words.toLowerCase(), words.toUpperCase()];
		var highlighted = crJsNs.search.highlightHTML( html, word );
		//console.log(highlighted);
		$('.topic-inner').empty();
		$('.topic-inner').append(highlighted);
	}
}


//スワイプ時、次の要素のhrefの値を取得し返す
function prevLink()
{

	//var currentHash = location.hash;
    var currentHash = window.location.href.split('/').pop();

	if(currentHash.match(/\?SEARCH=/))
	{
		currentHash = currentHash.substring(0, currentHash.indexOf("?"));
	}
	else if(currentHash.match(/#/))
	{
		currentHash = currentHash.substring(0, currentHash.indexOf("#"));
	}

	//var currentNode = $("#detailed_menu").find("a[href='" + currentHash + "']");
	var currentNode = $("#detailed_menu").find("a[href $= '" + currentHash + "']");

	//兄要素があった場合
	if(currentNode.parent("li").prev("li").length > 0)
	{

		if(currentNode.parent("li").prev("li").find("ul").length > 0 )
		{
			//alert("兄要素のliにはリストが含まれているので最後のli要素を取得");
			//alert(currentNode.parent("li").prev("li").find("ul li:last a").attr("href"));
			return currentNode.parent("li").prev("li").find("ul li:last a").attr("href");

		}
		else
		{
			//alert("兄要素がありました");
			//alert(currentNode.parent("li").prev("li").children("a").attr("href"));
			return currentNode.parent("li").prev("li").children("a").attr("href");

		}

	}
	//兄要素がなかった場合
	else
	{

		if(currentNode.parent("li").parent("ul").prev("a").length > 0)
		{
			//alert("兄要素がありません");
			//alert(currentNode.parent("li").parent("ul").prev("a").attr("href"));
			return currentNode.parent("li").parent("ul").prev("a").attr("href");
		}
		else
		{
			//alert("例外");
			return null;
		}

	}

}




//スワイプ時、次の要素のhrefの値を取得し返す
function nextLink()
{

//	var currentHash = location.hash;
    var currentHash = window.location.href.split('/').pop();
    
	if(currentHash.match(/\?SEARCH=/))
	{
		currentHash = currentHash.substring(0, currentHash.indexOf("?"));
	}
	else if(currentHash.match(/#/))
	{
		currentHash = currentHash.substring(0, currentHash.indexOf("#"));
	}


	var currentNode = $("#detailed_menu").find("a[href $= '" + currentHash + "']");

	//何階層目かチェック
	if(currentNode.parents("ul").length == 0)
	{

		//子要素が存在しない場合
		if(currentNode.next("ul").length == 0)
		{

			//最後のメニューの場合
			if(currentNode.parent("li").next("li").length == 0)
			{
				//alert("ルート最後");
				return null;
			}
			else
			{
				//alert(currentNode.parent("li").next("li").children("a").attr("href"));
				return currentNode.parent("li").next("li").children("a").attr("href");
			}

		}
		else
		{
			//alert(currentNode.next("ul").children("li").children("a").attr("href"));
			return currentNode.next("ul").children("li").children("a").attr("href");
		}

	}
	else if(currentNode.parents("ul").length == 1)
	{

		//alert("兄要素がないため親要素の弟要素の中にあるliを取得する");
		//alert(currentNode.next("ul").children("li").children("a").attr("href"));
		//return currentNode.next("ul").children("li").children("a").attr("href");

		//子要素が存在しない場合
		if(currentNode.next("ul").length == 0)
		{
			//最後のメニューの場合
			if(currentNode.parent("li").next("li").length == 0)
			{

				if(currentNode.closest("ul").parent("li").next("li").length == 0)
				{
					//alert("これ以上はなし");
					return null;

				}
				else
				{
					//alert(currentNode.closest("ul").parent("li").next("li").children("a").attr("href"));
					return currentNode.closest("ul").parent("li").next("li").children("a").attr("href");
				}

			}
			else
			{
				//alert(currentNode.parent("li").next("li").children("a").attr("href"));
				return currentNode.parent("li").next("li").children("a").attr("href");
			}
		}
		else
		{
			//alert(currentNode.next("ul").children("li").children("a").attr("href"));
			return currentNode.next("ul").children("li").children("a").attr("href");
		}

	}
	else if(currentNode.parents("ul").length == 2)
	{

		//alert("兄要素がないため親要素の弟要素の中にあるliを取得する");
		//alert(currentNode.next("ul").children("li").children("a").attr("href"));
		//return currentNode.next("ul").children("li").children("a").attr("href");

		//最後のメニューの場合
		if(currentNode.parent("li").next("li").length == 0)
		{

			//2階層目の弟要素がない場合
			if(currentNode.closest("ul").parent("li").next("li").length == 0)
			{

				if(currentNode.closest("ul").parent("li").parent("ul").parent("li").next("li").length == 0)
				{
					//alert(currentNode.closest("ul").parent("li").parent("ul").parent("li").next("li").children("a").attr("href"));
					//return currentNode.closest("ul").parent("li").parent("ul").parent("li").next("li").children("a").attr("href");
					
					//alert("これ以上はなし");
					return null;
				}
				else
				{
					//alert(currentNode.closest("ul").parent("li").parent("ul").parent("li").next("li").children("a").attr("href"));
					return currentNode.closest("ul").parent("li").parent("ul").parent("li").next("li").children("a").attr("href");
				}

			}
			//弟要素へ移動
			else
			{
				//alert(currentNode.closest("ul").parent("li").next("li").children("a").attr("href"));
				return currentNode.closest("ul").parent("li").next("li").children("a").attr("href");
			}

		}
		else
		{
			//alert(currentNode.parent("li").next("li").children("a").attr("href"));
			return currentNode.parent("li").next("li").children("a").attr("href");
		}

	}

}


function showPage(currentPageNumber)
{
	var page="#page-" + currentPageNumber;

	$('.selection').hide();
	$(page).show();

}



